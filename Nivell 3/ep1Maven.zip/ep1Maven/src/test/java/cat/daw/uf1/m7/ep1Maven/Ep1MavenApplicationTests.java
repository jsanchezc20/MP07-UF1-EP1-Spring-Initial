package cat.daw.uf1.m7.ep1Maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ep1MavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
