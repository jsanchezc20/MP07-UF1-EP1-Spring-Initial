package cat.daw.uf1.m7.ep1Maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ep1MavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ep1MavenApplication.class, args);
	}

}
